package com.domivoice.app.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

enum class TtsState { IDLE, PLAYING, STOPPED, ERROR }

class TtsManager(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    
    private val _state = MutableStateFlow(TtsState.IDLE)
    val state: StateFlow<TtsState> = _state

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "DO"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("es", "ES"))
            }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { _state.value = TtsState.PLAYING }
                override fun onDone(utteranceId: String?) { _state.value = TtsState.STOPPED }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { _state.value = TtsState.ERROR }
            })
        } else {
            _state.value = TtsState.ERROR
        }
    }

    fun speak(text: String, speed: Float = 1.0f, pitch: Float = 1.0f) {
        tts?.setSpeechRate(speed)
        tts?.setPitch(pitch)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "DOMI_TTS")
    }

    fun stop() {
        tts?.stop()
        _state.value = TtsState.STOPPED
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}