package com.domivoice.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.domivoice.app.data.AppDatabase
import com.domivoice.app.domain.DominicanPhoneticEngine
import com.domivoice.app.domain.TextNormalizer
import com.domivoice.app.tts.TtsManager
import com.domivoice.app.ui.MainApp
import com.domivoice.app.viewmodel.AppViewModel
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val db = AppDatabase.getDatabase(this)
        val normalizer = TextNormalizer()
        val engine = DominicanPhoneticEngine(normalizer)
        val ttsManager = TtsManager(this)

        val factory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return AppViewModel(db.domiDao(), engine, ttsManager) as T
            }
        }
        val viewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]

        setContent {
            MaterialTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    MainApp(viewModel)
                }
            }
        }
    }
}