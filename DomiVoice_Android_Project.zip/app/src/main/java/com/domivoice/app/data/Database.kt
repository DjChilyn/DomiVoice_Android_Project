package com.domivoice.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "dictionary")
data class DictionaryEntry(
    @PrimaryKey val original: String,
    val phonetic: String,
    val category: String = "general",
    val priority: Int = 1,
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "rules")
data class PhoneticRule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val pattern: String,
    val replacement: String,
    val priority: Int,
    val context: String = "general",
    val isEnabled: Boolean = true
)

@Entity(tableName = "exceptions")
data class PhoneticException(
    @PrimaryKey val original: String,
    val phonetic: String,
    val isEnabled: Boolean = true
)

@Entity(tableName = "history")
data class HistoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val originalText: String,
    val phoneticText: String
)

@Entity(tableName = "favorites")
data class FavoriteEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val originalText: String,
    val phoneticText: String,
    val title: String = ""
)

@Dao
interface DomiDao {
    @Query("SELECT * FROM dictionary ORDER BY original ASC")
    fun getAllDictionary(): Flow<List<DictionaryEntry>>
    
    @Query("SELECT * FROM dictionary WHERE isEnabled = 1")
    suspend fun getActiveDictionary(): List<DictionaryEntry>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDictionaryEntry(entry: DictionaryEntry)
    
    @Delete
    suspend fun deleteDictionaryEntry(entry: DictionaryEntry)

    @Query("SELECT * FROM rules ORDER BY priority DESC")
    fun getAllRules(): Flow<List<PhoneticRule>>
    
    @Query("SELECT * FROM rules WHERE isEnabled = 1 ORDER BY priority DESC")
    suspend fun getActiveRules(): List<PhoneticRule>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRule(rule: PhoneticRule)

    @Delete
    suspend fun deleteRule(rule: PhoneticRule)
    
    @Query("SELECT * FROM exceptions WHERE isEnabled = 1")
    suspend fun getActiveExceptions(): List<PhoneticException>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertException(exception: PhoneticException)

    @Query("SELECT * FROM history ORDER BY timestamp DESC")
    fun getHistory(): Flow<List<HistoryEntry>>

    @Insert
    suspend fun insertHistory(entry: HistoryEntry)

    @Query("DELETE FROM history")
    suspend fun clearHistory()

    @Query("SELECT * FROM favorites ORDER BY timestamp DESC")
    fun getFavorites(): Flow<List<FavoriteEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(entry: FavoriteEntry)
    
    @Delete
    suspend fun deleteFavorite(entry: FavoriteEntry)
}

@Database(entities = [
    DictionaryEntry::class, 
    PhoneticRule::class, 
    PhoneticException::class, 
    HistoryEntry::class, 
    FavoriteEntry::class
], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun domiDao(): DomiDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "domi_voice_database"
                ).addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Seed data
                        db.execSQL("INSERT INTO exceptions (original, phonetic, isEnabled) VALUES ('verdad', 'velada', 1)")
                        db.execSQL("INSERT INTO dictionary (original, phonetic, isEnabled) VALUES ('esperando', 'eperando', 1)")
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}