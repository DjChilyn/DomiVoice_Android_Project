package com.domivoice.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.*
import com.domivoice.app.viewmodel.AppViewModel
import com.domivoice.app.tts.TtsState

@Composable
fun MainApp(viewModel: AppViewModel) {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(icon = { Icon(Icons.Default.Home, "") }, label = { Text("Inicio") }, selected = false, onClick = { navController.navigate("home") })
                NavigationBarItem(icon = { Icon(Icons.Default.List, "") }, label = { Text("Diccionario") }, selected = false, onClick = { navController.navigate("dict") })
                NavigationBarItem(icon = { Icon(Icons.Default.DateRange, "") }, label = { Text("Historial") }, selected = false, onClick = { navController.navigate("hist") })
            }
        }
    ) { padding ->
        NavHost(navController, startDestination = "home", Modifier.padding(padding)) {
            composable("home") { HomeScreen(viewModel) }
            composable("dict") { DictionaryScreen(viewModel) }
            composable("hist") { HistoryScreen(viewModel) }
        }
    }
}

@Composable
fun HomeScreen(viewModel: AppViewModel) {
    val originalText by viewModel.originalText.collectAsState()
    val phoneticText by viewModel.phoneticText.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val ttsState by viewModel.ttsManager.state.collectAsState()
    val context = LocalContext.current

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = originalText,
            onValueChange = { viewModel.updateOriginalText(it) },
            label = { Text("Texto Original") },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { 
                if(originalText.isBlank()) Toast.makeText(context, "Escribe algún texto primero.", Toast.LENGTH_SHORT).show()
                else viewModel.transform() 
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isProcessing
        ) {
            Text(if (isProcessing) "Procesando..." else "TRANSFORMAR")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = phoneticText,
            onValueChange = { viewModel.updatePhoneticText(it) },
            label = { Text("Pronunciación Dominicana") },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            IconButton(onClick = { viewModel.ttsManager.speak(phoneticText) }) {
                Icon(if(ttsState == TtsState.PLAYING) Icons.Default.Face else Icons.Default.PlayArrow, "Escuchar")
            }
            IconButton(onClick = { viewModel.ttsManager.stop() }) {
                Icon(Icons.Default.Close, "Detener")
            }
            IconButton(onClick = { viewModel.saveFavorite(originalText, phoneticText) }) {
                Icon(Icons.Default.Favorite, "Favorito")
            }
        }
    }
}

@Composable
fun DictionaryScreen(viewModel: AppViewModel) {
    val dict by viewModel.dictionary.collectAsState(initial = emptyList())
    var newWord by remember { mutableStateOf("") }
    var newPhonetic by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Agregar al Diccionario", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(value = newWord, onValueChange = {newWord = it}, label = {Text("Original")}, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(value = newPhonetic, onValueChange = {newPhonetic = it}, label = {Text("Fonética")}, modifier = Modifier.weight(1f))
        }
        Button(onClick = {
            if(newWord.isNotBlank() && newPhonetic.isNotBlank()) {
                viewModel.addDictionaryWord(newWord, newPhonetic)
                newWord = ""; newPhonetic = ""
            }
        }, Modifier.fillMaxWidth()) { Text("Agregar") }
        
        Spacer(Modifier.height(16.dp))
        LazyColumn {
            items(dict) { entry ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Original: ${entry.original}", style = MaterialTheme.typography.bodyLarge)
                        Text("Fonética: ${entry.phonetic}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(viewModel: AppViewModel) {
    val history by viewModel.history.collectAsState(initial = emptyList())
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Button(onClick = { viewModel.clearHistory() }, Modifier.fillMaxWidth()) { Text("Limpiar Historial") }
        LazyColumn {
            items(history) { entry ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(entry.originalText, style = MaterialTheme.typography.bodyLarge)
                        Text("-> ${entry.phoneticText}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}