package com.domivoice.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.domivoice.app.data.*
import com.domivoice.app.domain.DominicanPhoneticEngine
import com.domivoice.app.tts.TtsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModel(
    private val dao: DomiDao,
    private val engine: DominicanPhoneticEngine,
    val ttsManager: TtsManager
) : ViewModel() {

    val dictionary = dao.getAllDictionary()
    val rules = dao.getAllRules()
    val history = dao.getHistory()
    val favorites = dao.getFavorites()

    private val _originalText = MutableStateFlow("")
    val originalText: StateFlow<String> = _originalText

    private val _phoneticText = MutableStateFlow("")
    val phoneticText: StateFlow<String> = _phoneticText
    
    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    fun updateOriginalText(text: String) { _originalText.value = text }
    fun updatePhoneticText(text: String) { _phoneticText.value = text }

    fun transform() {
        val text = _originalText.value
        if (text.isBlank()) return
        
        _isProcessing.value = true
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                val dict = dao.getActiveDictionary()
                val activeRules = dao.getActiveRules()
                val exc = dao.getActiveExceptions()
                engine.transformText(text, dict, activeRules, exc)
            }
            _phoneticText.value = result
            withContext(Dispatchers.IO) {
                dao.insertHistory(HistoryEntry(originalText = text, phoneticText = result))
            }
            _isProcessing.value = false
        }
    }
    
    fun clearHistory() = viewModelScope.launch(Dispatchers.IO) { dao.clearHistory() }
    
    fun saveFavorite(original: String, phonetic: String) = viewModelScope.launch(Dispatchers.IO) {
        dao.insertFavorite(FavoriteEntry(originalText = original, phoneticText = phonetic))
    }
    
    fun addDictionaryWord(original: String, phonetic: String) = viewModelScope.launch(Dispatchers.IO) {
        dao.insertDictionaryEntry(DictionaryEntry(original = original, phonetic = phonetic))
    }
}