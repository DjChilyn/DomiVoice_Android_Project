package com.domivoice.app.domain

import com.domivoice.app.data.DictionaryEntry
import com.domivoice.app.data.PhoneticRule
import com.domivoice.app.data.PhoneticException
import java.util.regex.Pattern

sealed class Token {
    data class Word(val text: String) : Token()
    data class Url(val text: String) : Token()
    data class Mention(val text: String) : Token()
    data class Hashtag(val text: String) : Token()
    data class PunctuationOrSpace(val text: String) : Token()
}

class TextNormalizer {
    private val urlPattern = Pattern.compile("https?://\\S+")
    private val mentionPattern = Pattern.compile("@\\w+")
    private val hashtagPattern = Pattern.compile("#\\w+")
    private val wordPattern = Pattern.compile("[\\p{L}0-9]+")

    fun tokenize(input: String): List<Token> {
        val tokens = mutableListOf<Token>()
        var currentIndex = 0
        
        while (currentIndex < input.length) {
            val urlMatcher = urlPattern.matcher(input).region(currentIndex, input.length)
            if (urlMatcher.lookingAt()) {
                tokens.add(Token.Url(urlMatcher.group()))
                currentIndex = urlMatcher.end()
                continue
            }
            
            val mentionMatcher = mentionPattern.matcher(input).region(currentIndex, input.length)
            if (mentionMatcher.lookingAt()) {
                tokens.add(Token.Mention(mentionMatcher.group()))
                currentIndex = mentionMatcher.end()
                continue
            }
            
            val hashtagMatcher = hashtagPattern.matcher(input).region(currentIndex, input.length)
            if (hashtagMatcher.lookingAt()) {
                tokens.add(Token.Hashtag(hashtagMatcher.group()))
                currentIndex = hashtagMatcher.end()
                continue
            }
            
            val wordMatcher = wordPattern.matcher(input).region(currentIndex, input.length)
            if (wordMatcher.lookingAt()) {
                tokens.add(Token.Word(wordMatcher.group()))
                currentIndex = wordMatcher.end()
                continue
            }
            
            tokens.add(Token.PunctuationOrSpace(input[currentIndex].toString()))
            currentIndex++
        }
        return tokens
    }
}

class DominicanPhoneticEngine(private val normalizer: TextNormalizer) {
    fun transformText(
        input: String,
        dictionary: List<DictionaryEntry>,
        rules: List<PhoneticRule>,
        exceptions: List<PhoneticException>
    ): String {
        val tokens = normalizer.tokenize(input)
        val result = StringBuilder()

        val excMap = exceptions.associateBy { it.original.lowercase() }
        val dictMap = dictionary.associateBy { it.original.lowercase() }

        for (token in tokens) {
            when (token) {
                is Token.Url, is Token.Mention, is Token.Hashtag, is Token.PunctuationOrSpace -> {
                    result.append(when(token) {
                        is Token.Url -> token.text
                        is Token.Mention -> token.text
                        is Token.Hashtag -> token.text
                        is Token.PunctuationOrSpace -> token.text
                        else -> ""
                    })
                }
                is Token.Word -> {
                    val originalWord = token.text
                    val lowerWord = originalWord.lowercase()
                    var transformedWord = lowerWord

                    if (excMap.containsKey(lowerWord)) {
                        transformedWord = excMap[lowerWord]!!.phonetic
                    } else if (dictMap.containsKey(lowerWord)) {
                        transformedWord = dictMap[lowerWord]!!.phonetic
                    } else {
                        for (rule in rules) {
                            try {
                                val regex = Regex(rule.pattern, RegexOption.IGNORE_CASE)
                                transformedWord = regex.replace(transformedWord, rule.replacement)
                            } catch (e: Exception) { }
                        }
                    }

                    val finalWord = if (originalWord.isNotEmpty() && originalWord[0].isUpperCase()) {
                        transformedWord.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                    } else {
                        transformedWord
                    }
                    result.append(finalWord)
                }
            }
        }
        return result.toString()
    }
}