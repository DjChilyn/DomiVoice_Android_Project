package com.domivoice.app

import com.domivoice.app.domain.*
import com.domivoice.app.data.*
import org.junit.Assert.assertEquals
import org.junit.Test

class EngineTest {
    @Test
    fun testTokenizerAndEngine() {
        val normalizer = TextNormalizer()
        val engine = DominicanPhoneticEngine(normalizer)
        
        val dict = listOf(DictionaryEntry("esperando", "eperando"))
        val exc = listOf(PhoneticException("verdad", "velada"))
        val rules = emptyList<PhoneticRule>()
        
        val result1 = engine.transformText("Estoy esperando la verdad.", dict, rules, exc)
        assertEquals("Estoy eperando la velada.", result1)
        
        // URL test
        val result2 = engine.transformText("Mira https://google.com verdad", dict, rules, exc)
        assertEquals("Mira https://google.com velada", result2)
        
        // Mention test
        val result3 = engine.transformText("Hola @juan esperando", dict, rules, exc)
        assertEquals("Hola @juan eperando", result3)
    }
}