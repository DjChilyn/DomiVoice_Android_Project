cd /mnt/data/domivoice_project
if [ -d "$ANDROID_HOME" ] || [ -d "$ANDROID_SDK_ROOT" ]; then
    gradle assembleDebug --no-daemon
else
    echo "NO_SDK"
fi